package model;

import java.io.File;
import java.util.List;

public interface Direktorijum {

	public void napraviDirektorijum(String putanja, String ime) throws Exception;
	
	public void obrisiDirektorijum(String putanja) throws Exception;
	
	public void download1(String imeDirektorijuma,String putanjaDirektorijuma) throws Exception;
	
	public void promeniIme(String putanja, String novoIme) throws Exception;
	
	public void ls(String putanja);
	

	
	void pretraziPoImenu(List<File> fajlovi, String direktorijum, String ime);
	
	
}
