package model;

import java.io.File;

public abstract class Glavna implements Fajl, Direktorijum {
	
	public String putanja;
	

	public Glavna() {
		
	}

	public String getPutanja() {
		return putanja;
	}

	public void setPutanja(String putanja) {
		this.putanja = putanja;
	}

	public abstract void dodajUsera(File file1);
	
	
}
