package model;

import java.io.File;
import java.util.List;

public interface Fajl {

	public void napraviFajl(String putanja, String ime) throws Exception;
	
	public void obrisiFajl(String putanja) throws Exception;
	
	public String download(String imeFajla,String putanjaFajla, String trenutni) throws Exception;
	
	public void promeniIme(String putanja, String novoIme) throws Exception;
	
	public void dodajZabranjenekstenzije(String ekstenzija, String putanja) throws Exception;
	
	public void ls(String putanja);
	
	
	void pretraziPoImenu(List<File> fajlovi, String direktorijum,String name);
	
	public String pretraziPoEkstenziji(String ekstenzija, String putanja);
	
	String upload(String fileName, String upload_path, String filePath);
	
	
	
}
