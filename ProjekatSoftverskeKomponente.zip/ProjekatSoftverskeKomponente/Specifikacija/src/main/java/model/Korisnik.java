package model;

import java.util.List;

public class Korisnik {

	public String korisnickoIme;
	public String lozinka;
	public List<String> privilegije;
	
	
	public String getKorisnickoIme() {
		return korisnickoIme;
	}
	public void setKorisnickoIme(String korisnickoIme) {
		this.korisnickoIme = korisnickoIme;
	}
	public String getLozinka() {
		return lozinka;
	}
	public void setLozinka(String lozinka) {
		this.lozinka = lozinka;
	}
	public List<String> getPrivilegije() {
		return privilegije;
	}
	public void setPrivilegije(List<String> privilegije) {
		this.privilegije = privilegije;
	}
	
	
	
	
	
}
