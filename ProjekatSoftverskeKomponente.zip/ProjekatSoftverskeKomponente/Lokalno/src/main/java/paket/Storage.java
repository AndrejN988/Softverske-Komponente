package paket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import model.Glavna;

public class Storage extends Glavna {

	public Storage() {
		
		// TODO Auto-generated constructor stub
	}

	public void napraviFajl(String putanja, String ime) throws Exception {
		  Path p1 = null;
	        if(putanja!= null && putanja.length()>0)
	            p1 = Paths.get(putanja);
	        if(ime==null || ime.equals(""))
	            throw new Exception("Prazno");

	        Path p = Paths.get(p1+  java.io.File.separator+ime);
	        if(Files.exists(p1) && Files.exists(p)==false){
	            try{
	                Files.createFile(p);

	                System.out.println("Uspesno kreiran fajl");
	            }
	            catch(Exception e){
	                e.printStackTrace();
	            }

	        }
	        else
	            throw new Exception("Fajl nije napravljen");
		
	}

	public void obrisiFajl(String putanja) throws Exception {
		if(putanja==null || putanja.equals(""))
            throw new Exception("prazno");
        Path p1 = Paths.get(putanja);
        if(Files.exists(p1)){
            try{
                Files.delete(p1);
                System.out.println("Uspesno obrisan fajl");
            }
            catch(Exception e){
                IOException exception = (IOException)e;
                e.printStackTrace();

            }
        }
        else
            throw new Exception("fajl nije obrisan");
		
	}

	

	public void promeniIme(String putanja, String novoIme) throws Exception {
		if(novoIme==null || novoIme.equals(""))
            throw new Exception("name is empty");
        if(putanja==null || putanja.equals(""))
            throw new Exception("path is empty");
        Path pathFile = Paths.get(putanja);
        if(Files.exists(pathFile)){
            try{
                File currFile = new File(putanja);
                File newFile = new File(currFile.getParent()+File.separator+novoIme);
                currFile.renameTo(newFile);
                System.out.println("Uspesno promenjeno ime fajla!");
            }
            catch(Exception e){
                IOException exception = (IOException)e;
                e.printStackTrace();
            }
        }
        else
            throw new Exception("File doesnt exist");
		
	}

	public void dodajZabranjenekstenzije(String ekstenzija, String putanja) throws Exception {
		
		FileReader citac = new FileReader(putanja);
	    JSONParser parser = new JSONParser();
	    parser.parse(citac);
		JSONObject obj= (JSONObject) parser.parse(citac);
		JSONArray eks= (JSONArray) obj.get("ext");
		eks.add(ekstenzija);
		
		BufferedWriter writer= new BufferedWriter(new FileWriter(putanja));
		writer.write(obj.toString());
		System.out.println(obj.toString());
		writer.close();
		
	}

	public void ls(String putanja) {
		File folder = new File(putanja);
		File[] listofFiles=folder.listFiles();
		int cnt=1;
		for(File f: listofFiles) {
			
			if(cnt==1) {
				int size= f.getName().length();
				String pom= "";
				for(int i=20-size; i>0;i--) {
					pom+=" ";
				}
				System.out.print(f.getName()+pom+"         ");
				
			}
			if(cnt==2) {
				System.out.println(f.getName());
				cnt=0;
			}
			cnt++;	
	
		}
		System.out.print("\n");
	}



	public void pretraziPoImenu(List<File> fajlovi, String direktorijum, String ime) {
		returnFiles(fajlovi, new File(direktorijum));
		
		for(File f : fajlovi) {
			if(f.getName().contains(ime))
	    	System.out.println(f.getName()+" -> " + f.getAbsolutePath().toString());
	    }
		
	}

	public String pretraziPoEkstenziji(String ekstenzija, String putanja) {
		File folder=new File(putanja);
		StringBuilder sb = new StringBuilder();
		
		File[] listOfFiles=folder.listFiles();
		
		if(ekstenzija.equals("dir")) {
			for(File f : listOfFiles) {
				if(!(f.getName().contains(".")))
		    	sb.append(f.getName()+" -> " + f.getAbsolutePath().toString());
			 }
			return sb.toString();
		}
		if(listOfFiles!=null) {
			
			for(File f:listOfFiles) {
			
				if(f.getName().endsWith("."+ekstenzija)) {
						sb.append(f.getName());
						for(int i=0; i<20-f.getName().length();i++) {
							sb.append(" ");
						}
						sb.append("->   ");
						sb.append(f.getAbsolutePath().toString());
						sb.append("\n");
					
				}
			}
			return sb.toString();
			
		}
		return "Ne postoji fajl sa ekstenzijom!";
	}

	public void napraviDirektorijum(String putanja, String ime) throws Exception {
		Path putanjaDirektorijuma;
        if(putanja!=null && putanja.length()!=0)
        	putanjaDirektorijuma = Paths.get(putanja);
        else
        	putanjaDirektorijuma = Paths.get(ime);
        if(ime==null || ime.length()==0)
            throw new Exception("Ime je prazno");

        Path p = Paths.get(putanjaDirektorijuma+ java.io.File.separator+ime);
        if(Files.exists(putanjaDirektorijuma) && Files.exists(p)==false){
            try {
                Files.createDirectory(p);
                System.out.println("direktorijum napravljen");
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        else
            throw new Exception("Direktorijum nije napravljen");
		
	}

	public void obrisiDirektorijum(String putanja) throws Exception {
		 if(putanja==null || putanja.length()==0)
	            throw new Exception("prazno");
	        Path p = Paths.get(putanja);
	        if(!(new File(putanja).isDirectory())){
	            throw new Exception("Nije direktorijum");
	        }

	        if(Files.exists(p)){
	            try{
	                File file = new File(putanja);
	                FileUtils.deleteDirectory(file);
	                System.out.println("fajl upesno izbrisan!");
	            }
	            catch(Exception e){
	                IOException exception = (IOException)e;
	                exception.printStackTrace();
	            }
	        }
	        else
	            throw new Exception("ne postoji direktorijum");
		
	}

	public String upload(String imeFajla, String putanja, String current) {
		File folder=new File(current);
		File destinacija=new File(putanja);
		File[] listofFiles=folder.listFiles();
		for(File f: listofFiles) {
			if(f.getName().equals(imeFajla)) {
				if(f.isDirectory()) {
					
					try {
						FileUtils.copyDirectory(f, destinacija);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					return "Uspesno uploadovan folder.";
				}
				if(f.isFile()) {					
					try {
						FileUtils.copyFileToDirectory(f, destinacija);;
						return "Uspesno uploadovan fajl.";
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		
		return "Neuspesno";
	}
	
	
	@Override
	public void dodajUsera(File f) {
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		JSONObject user=new JSONObject();
		System.out.println("Novi korisnik.");
		System.out.println("Username: ");
		try {
			String username=reader.readLine();
			System.out.println("Password: ");
			String password=reader.readLine();
			
			user.put("username", username);
			user.put("password", password);
			
			JSONArray privileges=new JSONArray();
			System.out.println("Privilegije: ");
			System.out.println("");
			System.out.println("Privilegije: dodajKorisnika, napraviFajl, napraviDirektorijum, zipuj, pretrazi, obrisi");
			System.out.println("");
			
			String privilegija = "";
			
				privilegija=reader.readLine();
				if(!(privilegija.equals("dodajKorisnika") || privilegija.equals("napraviDirektorijum") || privilegija.equals("napraviFajl") || privilegija.equals("download") 
						  || privilegija.equals("upload") || privilegija.equals("obrisi") || privilegija.equals("pretrazi") || privilegija.equals("zipuj") )) {
							System.out.println("Niste uneli tacno ime privilegije. Pokusajte ponovo");
						}
						else if(privileges.contains(privilegija)) {
							System.out.println("Vec ste uneli tu privilegiju.");
						}else {
							privileges.add(privilegija);
							System.out.println("Privilegija dodata.");
							System.out.println("(Privilegije: dodajKorisnika, napraviDirektorijum,  zipuj, pretrazi, obrisi)");
							System.out.println("");
						}
						
			
			
			user.put("privileges", privileges);
			
			
			String path=f.getAbsolutePath().toString();
			JSONObject obj = null;
			try {
				FileReader reader1 = new FileReader(f.getAbsolutePath().toString());
			    JSONParser jsonParser = new JSONParser();
				
				obj = (JSONObject) jsonParser.parse(reader1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JSONArray users= (JSONArray) obj.get("korisnici");
		
			users.add(user);
			
			
			
			BufferedWriter writer=null;
			
			writer= new BufferedWriter(new FileWriter(f.getAbsolutePath().toString()));
			writer.write(obj.toString());
			System.out.println(path);
			writer.close();
			
			
			
			
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
		 
	private static List<File> returnFiles(List<File> fajlovi, File direktorijum) {
		
	    if(direktorijum.isFile()){
	        fajlovi.add(direktorijum);
	    }else{
	        fajlovi.add(direktorijum);
	        File f[] = direktorijum.listFiles();
	        for(File dirOrFile: f){
	        	returnFiles(fajlovi,dirOrFile);
	        }
	    }
	
	return fajlovi;
   
}

	

	public String download(String imeFajla, String putanjaFajla, String trenutni) throws Exception {
		File folder=new File(trenutni);
		File destinacija=new File(putanjaFajla);
		File[] listofFiles=folder.listFiles();
		for(File f: listofFiles) {
			if(f.getName().equals(imeFajla)) {
				if(f.isDirectory()) {
					
					try {
						FileUtils.copyDirectory(f, destinacija);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					return "Uspesno preuzeto.";
				}
				if(f.isFile()) {
					try {
						FileUtils.copyFileToDirectory(f, destinacija);
						return "Uspesno preuzeto.";
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		return "Ne postoji.";
		
	}

	public void download1(String imeDirektorijuma, String putanjaDirektorijuma) throws Exception {
		// TODO Auto-generated method stub
		
	}

	


	

	
	
}
