package paket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import model.Glavna;
import net.lingala.zip4j.ZipFile;

public class Main {
	
	
		static Glavna folder= new Storage();
		//static Korisnik user=new Korisnik();
		static String root;
		
		
	public static void main(String[] args) throws Exception {
		
		BufferedReader citac=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Unesite putanju repozitorijuma?");
		String odgovor="";
		
			odgovor=citac.readLine();
		
		
		folder.setPutanja(odgovor);
		root=odgovor;
		String path=odgovor;
		File file1=new File(odgovor);
		
		File file2=new File(odgovor);
		if(!(file1.exists())) {
			
			while(!(file1.exists())) {
				System.out.println("Repozitorijum ne postoji. Pokusajte ponovo.");
				
				try {
					path = citac.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				file1=new File(path);
			}
			
			
		}
		
		boolean postoji=false;
		File[] lista=file1.listFiles();
		for (File file : lista) {
		    if (file.getName().equals("korisnici.json")) {
		    	file2=new File(file.getAbsolutePath().toString());
		    	postoji=true;
		    	
		    }
		}
	if(postoji==false) {
		if(path.endsWith("\\")){
			file1 = new File(path+"korisnici.json");
		}else {
			file1 = new File(path+"\\korisnici.json");
		}
		try {
			file1.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String username=null, password=null;
		System.out.println("Vi ste glavni korisnik!");
		
		
		System.out.println("Unesite username: ");
	
			username=citac.readLine();
		
		System.out.println("Unesite password: ");
		
			password=citac.readLine();
		
		
		
		JSONObject skladiste = new JSONObject();
		JSONArray korisnici = new JSONArray();
		JSONObject korisnik = new JSONObject();
		korisnik.put("username", username);
		korisnik.put("password", password);
		JSONArray privilegije= new JSONArray();
		privilegije.add("dodajKorisnika");
		privilegije.add("napraviDirektorijum");
		privilegije.add("napraviFajl");
		privilegije.add("zipuj");
		privilegije.add("upload");
		privilegije.add("pretrazi");
		privilegije.add("obrisi");
		privilegije.add("dodajZabranjeneEkst");
		korisnik.put("privileges", privilegije);
		korisnici.add(korisnik);
		
		skladiste.put("korisnici", korisnici);
		
		BufferedWriter writer=null;
		
	
			writer= new BufferedWriter(new FileWriter(file1.getAbsolutePath().toString()));
		
			writer.write(skladiste.toString());
		
			writer.close();
	
		file2=file1;
		}
		//file1
		
		System.out.println("Ulogujte se?");
		System.out.println("Username:");
		String username1=citac.readLine();
		System.out.println("Password:");
		String password1=citac.readLine();
		
		 File file3=file2;
		 
		String usr1=username1;
		String pass1=password1;
		Korisnik korisnikP=new Korisnik();
		
		FileReader citac1 = new FileReader(file3.getAbsoluteFile().toString());
	    JSONParser parser1 = new JSONParser();
	   
		
		JSONObject obj= (JSONObject) parser1.parse(citac1);
		JSONArray users= (JSONArray) obj.get("korisnici");
		String user="",pass="";
		
		List<String> userP= new ArrayList<String>();
		List<String> passP= new ArrayList<String>();
		for(Object o: users){
		    if ( o instanceof JSONObject ) {
		    	user= ((JSONObject) o).get("username").toString();
		    	pass= ((JSONObject) o).get("password").toString();
		    	userP.add(user);
		    	passP.add(pass);
		    	}
		    }
		
		int i=0;
			while(!(userP.get(i).equals(usr1)) || !(passP.get(i).equals(pass1)) ) {
				if(!(userP.get(i).equals(usr1))) {
					System.out.println("Pogresan username!");
				}
				else if(!(passP.get(i).equals(pass1))) {
					System.out.println("Pogresan password!");
				}
				
				System.out.println("Username:");
				 usr1=citac.readLine();
				System.out.println("Password:");
				 pass1=citac.readLine();
				i++;
			
			}
		
		
	citac1.close();
		
		List<String> privileges=new ArrayList<String>();

		FileReader citac2 = new FileReader(file2.getAbsoluteFile().toString());
	    JSONParser parser2 = new JSONParser();
	   
		
		 obj= (JSONObject) parser2.parse(citac2);
		
			 users= (JSONArray) obj.get("korisnici");
			for(Object o: users){
			    if ( o instanceof JSONObject ) {
			    	 
			    	if(((JSONObject) o).get("username").toString().equals(usr1) && ((JSONObject) o).get("password").toString().equals(pass1)){
			    	 JSONArray privile= (JSONArray) ((JSONObject) o).get("privileges");			    	
			    	 for(Object pri:  privile) {
			    		 if(pri instanceof String) {
			    			 privileges.add((String) pri);
			    			 
			    		 }
			    	 }
			    	 Korisnik u= new Korisnik(usr1, pass1);
				 		u.setPrivilegije(privileges);
				 		
				 		
			    	}
			    	
			       
			    }
			}
			
		
		Korisnik u= new Korisnik(usr1, pass1);
		
		u.setPrivilegije(privileges);
	
		citac2.close();
	//do ovdeeeeeee	
		
		korisnikP=u;
		
		  String answer= "";
	        
			while(!(answer.equals("end"))) {
				
				System.out.println("");
				System.out.println(  "'cmd' za prikaz komandi" );
				System.out.println("");
				
				System.out.println(odgovor  );
				answer=citac.readLine();
				List<String> privileges1= korisnikP.getPrivilegije();
				
				if(answer.equals("1") && privileges1.contains("dodajKorisnika")) {
					try {
						folder.dodajUsera(file1);
					} catch (Exception e) {
						
						e.printStackTrace();
					}
					continue;
				}else
				if(answer.equals("2") && privileges1.contains("napraviDirektorijum")) {
					String name;
					System.out.println("Ime direktorijuma?:");
					name=citac.readLine();
					String brojFoldera;
				
					
					
					folder.napraviDirektorijum(odgovor, name );
					
					
					continue;
					
					
					
				}else
				if(answer.equals("3") && privileges1.contains("napraviFajl")) {
					String name;
					System.out.println("Ime fajla?:");
					name=citac.readLine();
					folder.napraviFajl(odgovor,name);
					System.out.println();
					continue;
				}else
				if(answer.equals("4") && privileges1.contains("download")) {
					String name;
					System.out.println("Unesite ime fajl koji zelite da preuzmete:");
					name=citac.readLine();
					String putanja;
					System.out.println("Unesite putanju na kojoj zelite da se fajl preuzme: ");
					putanja=citac.readLine();
					folder.download(name, putanja,odgovor);
					continue;
				}
				else if(answer.equals("5") && privileges1.contains("upload")) {
					String name;
					System.out.println("Unesite ime fajla koji zelite da uploadujete: ");
					name=citac.readLine();
					String putanja;
					System.out.println("Unesite putanju sa koje zelite da fajl bude uploadovan: ");
					putanja=citac.readLine();
					folder.upload(name, putanja, odgovor);
				}else
				if(answer.equals("6") && privileges1.contains("pretrazi")) {
					
					System.out.println("Ime fajla?");
					String name=citac.readLine();
					List<File> list= new ArrayList<File>();
					folder.pretraziPoImenu(list, odgovor, name);
					
				}else
				if(answer.equals("7") && privileges1.contains("obrisi")) {
					System.out.println("Ime fajla?");
					String name=citac.readLine();
					
					folder.obrisiFajl(odgovor+"\\"+name);
					
					continue;
				}else if(answer.equals("8") && privileges1.contains("zipuj")) {
					String name;
					System.out.println("Unesite folder ili fajl koji zelite da zipujete :");
					name=citac.readLine();
					String destination;
					
					
						zipuj(odgovor, name, odgovor);
					
					continue;
				}else if(answer.equals("ls")) {
					folder.ls(odgovor);
					continue;
				}else if(answer.equals("end")){
					break;
				}else if(answer.equals("cmd")){
					korisnikP.prikazi(odgovor,folder);
					
				}else {
					System.out.println(" opcija ne postoji. pokusajte ponovo.");
					System.out.println("");
				}
			}
			System.out.println("Uspesno ste se izlogovali");
		
		
		
		
		
		citac.close();
		
		
		

	}
	
	public static void zipuj(String file, String name, String dest) {
		ZipFile zip= new ZipFile(dest+"\\"+name+".zip");	
		File folder= new File(file+"\\"+name);
		
		if(folder.isDirectory()) {
			folder= new File(file+"\\"+name);
			File[] listofFiles= folder.listFiles();
			for(File f: listofFiles) {
				f= new File(file+"\\"+name);
				try {
					zip.addFolder(f);
					System.out.println("Zipovanje uspelo!");
				} catch (Exception e) {
						System.out.println("Zipovanje nije uspelo");
						return;
				}
			
			}
		}
		if(folder.isFile()) {
			try {
			
				zip.addFile(folder);
				System.out.println("Zipovanje uspelo!");
			} catch (Exception e) {
				System.out.println("Zipovanje nije uspelo");
				return;
			}
		}
	}
	
	
	
	
	


}
