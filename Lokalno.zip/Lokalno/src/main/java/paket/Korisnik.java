package paket;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import model.Glavna;

public class Korisnik extends model.Korisnik{
		
	
		public Korisnik(String korisnickoIme, String lozinka) {
				super.korisnickoIme=korisnickoIme;
				super.lozinka=lozinka;
		}

		public Korisnik() {
			// TODO Auto-generated constructor stub
		}

		public void prikazi(String odgovor, Glavna folder) {
			int br;
			BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
			StringBuilder sb=new StringBuilder();
			
			
			sb.append(odgovor+ "\n");
			if(privilegije.contains("dodajKorisnika")) {
				br=1;
				
				sb.append("Izaberite "+br+" za dodavanje novog korisnika");
				
			}
			if(privilegije.contains("napraviDirektorijum")) {
				br=2;
				sb.append("\n");
				sb.append("Izaberite "+br+" za dodavanje novog foldera");
			}
			if(privilegije.contains("napraviFajl")) {
				br=3;
				sb.append("\n");
				sb.append("Izaberite "+br+" za dodavanje novog fajla");
			}
			if(privilegije.contains("download")) {
				br=4;
				sb.append("\n");
				sb.append("Izaberite "+br+" za preuzimanje fajla");
			}
			if(privilegije.contains("upload")) {
				br=5;
				sb.append("\n");
				sb.append("Izaberite "+br+ " za upload fajla");
			}
			if(privilegije.contains("pretrazi")) {
				br=6;
				sb.append("\n");
				sb.append("Izaberite "+br+" za pretragu repozitorijuma");
			}
			if(privilegije.contains("obrisi")) {
				br=7;
				sb.append("\n");
				sb.append("Izaberite "+br+" za brisanje fajla");
			}
			if(privilegije.contains("zipuj")) {
				br=8;
				sb.append("\n");
				sb.append("Izaberite "+br+" za zip fajla");
			}
			
			
			sb.append("\n");
			sb.append("ls za prikaz sadrzaja");
			sb.append("\n");
			System.out.print(sb.toString());
			
		}
		
		
}
