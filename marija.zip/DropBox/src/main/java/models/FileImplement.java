package models;

import java.awt.HeadlessException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;

import javax.swing.JOptionPane;

import com.dropbox.core.DbxApiException;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.DeleteErrorException;
import com.dropbox.core.v2.files.FileMetadata;
import com.dropbox.core.v2.files.GetMetadataErrorException;
import com.dropbox.core.v2.files.LookupError;
import com.dropbox.core.v2.files.UploadErrorException;
import com.dropbox.core.v2.users.FullAccount;


import login.ApiKorisnik;
import login.Login;

public class FileImplement extends MyFile{
	
	private static final String ACCESS_TOKEN = "kZJ3FY2OQBAAAAAAAAAATJEVHvIDWXSAjswjuzgA9uQOKLKnxrExnwXM8x6vJrEG";
	private static final String DROP_BOX_APP_KEY = "g3czi22kkwlizj3";
	private static final String DROP_BOX_APP_SECRET = "fqqlgq73n04sqr7";
	DbxClientV2 dbxClient;
	FullAccount account = null;
	DbxRequestConfig config = null;
	Login login = new Login();
	
	public FileImplement(){
		clientConnect();
	}

	@Override
	public void napraviFajl(String name, String path) throws CreateFileException {
		
		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isAdd()) {
			JOptionPane.showMessageDialog(null, "Nemate privilegiju za ovu akciju!");
			return;
		}
		
		path = makePath(path);
		path = path.replace("//", "/");
		
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(path)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		
		//Trenutno kreiramo fajl na disku, da bi mogli da ga upload-ujemo ----------------------
		String tmpPath = System.getProperty("user.dir") + "\\src\\test\\resources";
		Path realPath;
		
		//Proverava da li je path ispravan
		try {
			realPath = Paths.get(tmpPath);
		} catch (InvalidPathException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "Neispravna putanja! Pokusajte ponovo.");
			return;
		}
		
		
		//Ako je path ispravan,kreiramo u tom direktorijumu fajl (sluzi za proveru da li postoji dir)		
		File file = new File(tmpPath + File.separator + name);
		
		//Proverava da li direktorijum vec postoji i ujedno kreira fajl
		try {
			if(file.createNewFile()) {
				// Kreira fajl
			}else{
				JOptionPane.showMessageDialog(null, "Fajl vec postoji!");
				return;
			}
		} catch (HeadlessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//-----------------------------------------------------------------------------------------
		
		
		//Upload-uje fajl na dropbox
		try {
			upload(file.getPath(),path,false);
		} catch (UploadFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//Brisanje fajla sa diska
		if(file.exists()) {
			file.delete();
		}else {
			JOptionPane.showMessageDialog(null, "Fajl ne postoji!");
			return;
		}
		
	}

	@Override
	public void delete(String path) throws DeleteFileException {
		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isDelete()) {
			JOptionPane.showMessageDialog(null, "Nemate privilegiju za ovu akciju!");
			return;
		}
		
		String fullPath = makePath(path);
		
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		try {
			dbxClient.files().delete(fullPath.replace("//", "/"));
		} catch (DeleteErrorException e) {
			JOptionPane.showMessageDialog(null, "Greska: " + e);
			return;
		} catch (DbxException e) {
			JOptionPane.showMessageDialog(null, "Greska: " + e);
			return;
		}
	}

	@Override
	public void upload(String sourcePath, String destinationPath, boolean meta) throws UploadFileException {
		String fullPath = makePath(destinationPath);
		
		
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		if(new File(sourcePath).isDirectory()) {
			JOptionPane.showMessageDialog(null, "Uneli ste putanju do foldera, a treba putanju do fajla da unesete!");
			return;
		}

		System.out.println("SP: "  + sourcePath);

		//Dobijanje imena fajla iz putanje ----------
		String[] pathParts = sourcePath.split("\\\\");
		String name = pathParts[pathParts.length-1];
		fullPath += "/" + name;
		fullPath = fullPath.replace("//", "/");
		//-------------------------------------------
		
		try {
			
			System.out.println("DP: "  + fullPath.replace("//", "/"));
			InputStream in = new FileInputStream(sourcePath);
			FileMetadata metadata = dbxClient.files().uploadBuilder(fullPath.replace("//", "/")).uploadAndFinish(in);
		} catch (UploadErrorException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Greska: " + e);
			return;
		} catch (DbxException e) {
			JOptionPane.showMessageDialog(null, "Greska: " + e);
			return;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Greska: " + e);
			return;		
		}
		
		
		
		// Provera da li postoje meta podaci za ovaj fajl ----------------------------------------------------------
		String[] deloviPatha = sourcePath.split("\\\\"); 
		String nameSource = deloviPatha[deloviPatha.length-1];
		
		String[] nameParts = nameSource.split("\\.");


		String nameFile = nameParts[0] + ".json";
		String tmp = "";
		
		for(int i=0;i<deloviPatha.length-1;i++) {
			tmp += deloviPatha[i] + "\\";
		}

		tmp += nameFile;
		
		File jsonFile = new File(tmp);
		boolean fleg = false;
		
		if(meta == true) {
			if(!jsonFile.exists()) {
				JOptionPane.showMessageDialog(null, "Ne postoje meta podaci za fajl: " + jsonFile.getName());
				return;
			}else {
				fleg = true;
			}
		}
		//-----------------------------------------------------------------------------------------------------------
		
		
		//Ako postoje meta podaci za fajl, onda i njih upload-ujemo --------------------------------------------------
		if(fleg == true) {
			fullPath = changeFileNameInPath(fullPath);
			try {
				InputStream in = new FileInputStream(jsonFile.getPath());
				FileMetadata metadata = dbxClient.files().uploadBuilder(fullPath.replace("//", "/")).uploadAndFinish(in);
			} catch (UploadErrorException e) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "Greska: " + e);
				return;
			} catch (DbxException e) {
				JOptionPane.showMessageDialog(null, "Greska: " + e);
				return;
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Greska: " + e);
				return;		
			}
		}
		//---------------------------------------------------------------------------------------------------------------

		
	}

	@Override
	public void download(String sourcePath, String destinationPath, boolean meta) throws DownloadFileException {

		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isDownload()) {
			JOptionPane.showMessageDialog(null, "Nemate privilegiju za ovu akciju!");
			return;
		}
		
		String fullPath = makePath(sourcePath);
		fullPath = fullPath.replace("//", "/");

		System.out.println(fullPath);
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		String[] pathParts = fullPath.split("/");
		String name = pathParts[pathParts.length-1];
				
		OutputStream downloadFile = null;
		try
        {
			System.out.println("Source path: " + fullPath);

        	downloadFile = new FileOutputStream(destinationPath + "/" + name);
        	FileMetadata metadata = dbxClient.files().downloadBuilder(fullPath).download(downloadFile);
        } catch (DbxException e) {
			JOptionPane.showMessageDialog(null, "Greska prilikom download-a fajla! Greska: " + e);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Greska prilikom download-a fajla! Greska: " + e);
		}
        finally
        {
			try {
				downloadFile.close();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(null, "Greska prilikom download-a fajla! Greska: " + e);
			}

        }

	}
	
	
	/**
	 * Menja ekstenziju datog fajla u .json ekstenziju.
	 * 
	 * @param sourcePath Putanja do fajla.
	 * @return
	 */
	public String promeniIme(String sourcePath) {
		
		String[] deloviPatha = sourcePath.split("\\\\"); 
		String nameSource = deloviPatha[deloviPatha.length-1];
		
		String[] nameParts = nameSource.split("\\.");


		String nameFile = nameParts[0] + ".json";
		String tmp = "";
		
		for(int i=0;i<deloviPatha.length-1;i++) {
			tmp += deloviPatha[i] + "\\";
		}

		tmp += nameFile;
		
		return tmp;
	}
	
}
