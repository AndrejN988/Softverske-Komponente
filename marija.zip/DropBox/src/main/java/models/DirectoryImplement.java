package models;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.JOptionPane;

import com.dropbox.core.DbxApiException;
import com.dropbox.core.DbxDownloader;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.CreateFolderErrorException;
import com.dropbox.core.v2.files.DeleteErrorException;
import com.dropbox.core.v2.files.DownloadZipErrorException;
import com.dropbox.core.v2.files.DownloadZipResult;
import com.dropbox.core.v2.files.FileMetadata;
import com.dropbox.core.v2.files.FolderMetadata;
import com.dropbox.core.v2.files.GetMetadataErrorException;
import com.dropbox.core.v2.files.ListFolderBuilder;
import com.dropbox.core.v2.files.ListFolderResult;
import com.dropbox.core.v2.files.LookupError;
import com.dropbox.core.v2.files.Metadata;
import com.dropbox.core.v2.files.UploadErrorException;
import com.dropbox.core.v2.users.FullAccount;


import model.Korisnik;


public class DirectoryImplement extends MyDirectory{
	
	private static final String ACCESS_TOKEN = "kZJ3FY2OQBAAAAAAAAAATJEVHvIDWXSAjswjuzgA9uQOKLKnxrExnwXM8x6vJrEG";
	private static final String DROP_BOX_APP_KEY = "g3czi22kkwlizj3";
	private static final String DROP_BOX_APP_SECRET = "fqqlgq73n04sqr7";
	DbxClientV2 dbxClient;
	FullAccount account = null;
	DbxRequestConfig config = null;
	Login login = new Login();
	
	public DirectoryImplement(){
		clientConnect();
	}

	@Override
	public void napraviDirektorijum(String name, String path)  {
	
	
		
		String fullPath = makePath(path);
		
		
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		System.out.println(path);
		fullPath += "/" + name;
		System.out.println("---------"+fullPath);
	
		try {
			System.out.println(fullPath);
			FolderMetadata folder = dbxClient.files().createFolder(fullPath.replace("//", "/"));
		} catch (CreateFolderErrorException e) {
			if(e.errorValue.isPath() && e.errorValue.getPathValue().isConflict()) {
				JOptionPane.showMessageDialog(null, "Ovaj direktorijum vec postoji!");
				return;
			}else {
				JOptionPane.showMessageDialog(null, "Greska!");
				return;
			}
		} catch (DbxException e) {
			JOptionPane.showMessageDialog(null, "Greska!");
			return;			
			//e.printStackTrace();
		} 

	}

	@Override
	public void obrisi(String path)  {
		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isDelete()) {
			JOptionPane.showMessageDialog(null, "Nemate privilegiju za ovu akciju!");
			return;
		}
		
		String fullPath = makePath(path);
		
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		try {
			dbxClient.files().delete(fullPath.replace("//", "/"));
		} catch (DeleteErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DbxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void upload(String sourcePath, String destinationPath)  {
		
		String fullPath = makePath(destinationPath);
		
		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		
		try {
			InputStream in = new FileInputStream(sourcePath);
			FileMetadata metadata = dbxClient.files().uploadBuilder(fullPath.replace("//", "/")).uploadAndFinish(in);
		} catch (UploadErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DbxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void download(String sourcePath, String destinationPath)  {
		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isDownload()) {
			JOptionPane.showMessageDialog(null, "Nemate privilegiju za ovu akciju!");
			return;
		}
		
		String fullPath = makePath(sourcePath);

		// Proverava da li je putanja do foldera ispravna, to jest da li folder postoji ----
		if(!folderExist(fullPath)) {
			JOptionPane.showMessageDialog(null, "Pogresna putanja do foldera!");
			return;
		}
		//----------------------------------------------------------------------------------
		
		String[] pathParts = fullPath.replace("//", "/").split("/");
		String name = pathParts[pathParts.length-1];
		
			DbxDownloader<DownloadZipResult> result;
			try {
				result = dbxClient.files().downloadZip(fullPath.replace("//", "/"));
				result.download(new FileOutputStream(destinationPath + "/" + name + ".zip")); 

			} catch (DownloadZipErrorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DbxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	}

	@Override
	public void dodajUsera(File f) throws CreateUserException {
		
		FileImplement dir = new FileImplement();
		
		if(!ApiKorisnik.getInstance().getTmpKorisnik().isMainUser()) {
			JOptionPane.showMessageDialog(null, "Vi niste glavni korisnik i nemate privilegiju da kreirate ostale korisnike!");
			return false;
		}
		
		
		Login login = new Login();
		

		
		File jsonFile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\\\korisnici.json");
		
		//Provera da li je uneti path validan
		if(!jsonFile.exists()) {
			JOptionPane.showMessageDialog(null, "Greska, ne moze se otvoriti fajl sa korisnicima.");
			return false;
		}
		
		
		String sviKorisnici = login.createOrdinaryUser(username, password, jsonFile.getPath(), false, privilegije);	//Vraca json string sa svim korisnicima
		
		
		//Azuriranje novih korisnika u json fajl------------------
		try {
			FileWriter writer = new FileWriter(jsonFile);
			writer.write(sviKorisnici);
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String destinationPath = path; //Putanja na koju cemo smestiti azuriranu listu korisnika
		
		path += "/korisnici.json";
		path = makePath(path);
		path = path.replace("//", "/");
		path = path.replace("//", "/");

		
		System.out.println("pathhh: " + path);
		
		if(!folderExist(path)) {
			JOptionPane.showMessageDialog(null, "Json fajl sa korisnicima ne postoji!");
			return false;
		}
		
		try {
			delete(path);
		} catch (DeleteDirectoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		FileImplement file = new FileImplement();
		try {
			file.upload(System.getProperty("user.dir") + "\\src\\test\\resources\\\\korisnici.json", destinationPath, false);
		} catch (UploadFileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
