package dropbox;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;

import javax.swing.JOptionPane;

import com.dropbox.core.DbxApiException;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.CreateFolderErrorException;
import com.dropbox.core.v2.files.DeleteErrorException;
import com.dropbox.core.v2.files.FileMetadata;
import com.dropbox.core.v2.files.FolderMetadata;
import com.dropbox.core.v2.files.GetMetadataErrorException;
import com.dropbox.core.v2.files.Metadata;
import com.dropbox.core.v2.users.FullAccount;

import model.Korisnik;
import login.Login;



public class DropboxMain {


	private static final String ACCESS_TOKEN = "kZJ3FY2OQBAAAAAAAAAATJEVHvIDWXSAjswjuzgA9uQOKLKnxrExnwXM8x6vJrEG";
	private static final String DROP_BOX_APP_KEY = "g3czi22kkwlizj3";
	private static final String DROP_BOX_APP_SECRET = "fqqlgq73n04sqr7";
	DbxClientV2 dbxClient;
	FullAccount account = null;
	DbxRequestConfig config = null;
	Login login = new Login();

	public DropboxMain() {
		config = new DbxRequestConfig("RemoteStorageComponent", Locale.getDefault().toString());
		dbxClient = new DbxClientV2(config, ACCESS_TOKEN);

		try {
			FullAccount account = dbxClient.users().getCurrentAccount();
			System.out.println(account.getName().getDisplayName());

		} catch (DbxApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DbxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws IOException, DbxException {

	}

	/**
	 * Kreira ili pristupa skladistu na dropbox-u. Dodaje korisnika u fajl sa korisnicima.
	 * 
	 * @param nazivSkladista Naziv kako zelimo da se zove skladiste.
	 * @param username Username korisnika koji pristupa skladistu.
	 * @param password Password korisnika koji pristupa skladistu.
	 * @return
	 * @throws DbxException
	 */
	public boolean createStorage(String nazivSkladista, String username, String password) throws DbxException{
		
		String mainUser = login.createMainUser(username, password);

		
		try {
			//Kreiramo skladiste ukoliko ne postoji, ukoliko postoji, idemo u catch blok
			FolderMetadata folder = dbxClient.files().createFolder(nazivSkladista); 
			
			//Ovo se desava ukoliko skladiste postoji. Ovde proveravamo da li skladiste ima json fajl(a nema ga sigurno, jer smo ga sad kreirali), ako nema kreiramo ga.
			try {
				dbxClient.files().getMetadata(nazivSkladista + "/korisnici.json");
			} catch (GetMetadataErrorException e){
				if (e.errorValue.isPath() && e.errorValue.getPathValue().isNotFound()) {
					
					try {
						dbxClient.files().upload(nazivSkladista  + "/korisnici.json").uploadAndFinish(new ByteArrayInputStream(mainUser.getBytes()));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						//e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Niste pravilno uneli putanju!");
						return false;
					}			
					
				} else {
					System.out.println("nadjen");
				}
			}
			

			//Ako postoji skladiste radmo ovo
		} catch (CreateFolderErrorException err) {
			if(err.errorValue.isPath() && err.errorValue.getPathValue().isConflict()) {
				
				//Ovo se desava kada skladiste postoji, tada treba da proverimo da li to skladiste ima json fajl. Ako nema kreiramo ga.
				try {
					dbxClient.files().getMetadata(nazivSkladista + "/korisnici.json");
					
					
					//-------PROVERA DA LI JE VALIDAN ------------------------------------------------------------------------------					
			        try
		            {
		                //output file for download --> storage location on local system to download file
		                OutputStream downloadFile = new FileOutputStream(System.getProperty("user.dir") + "\\src\\test\\resources\\\\korisnici.json");
		                try
		                {
		                FileMetadata metadata = dbxClient.files().downloadBuilder(nazivSkladista + "/korisnici.json").download(downloadFile);
		                }
		                finally
		                {
		                    downloadFile.close();
		                }
		            }
		            //exception handled
		            catch (DbxException e)
		            {
		                //error downloading file
		                JOptionPane.showMessageDialog(null, "Nije moguce sacuvati fajl na disk! Greska: " + e);
						return false;
		            }
		            catch (IOException e)
		            {
		                //error downloading file
		                JOptionPane.showMessageDialog(null, "Nije moguce sacuvati fajl na disk! Greska: " + e);
						return false;
		            }

					boolean validUser = login.isUserValid(username, password, System.getProperty("user.dir") + "\\src\\test\\resources\\korisnici.json");
					System.out.println(validUser);
					ApiKorisnik k2 = ApiKorisnik.getInstance().getTmpKorisnik();
					
					
					
					System.out.println("Add:::::::::::: " + k2.isAdd());
					System.out.println("Delete:::::::::::: " + k2.isDelete());
					System.out.println("Download:::::::::::: " + k2.isDownload());
					System.out.println("Main:::::::::::: " + k2.isMainUser());
					
					if(validUser) {
						return true;
					}else {
		                JOptionPane.showMessageDialog(null, "Pogresan username ili password!");
						return false;
					}
					//--------------------------------------------------------------------------------------------------------------

					
				} catch (GetMetadataErrorException e){
					if (e.errorValue.isPath() && e.errorValue.getPathValue().isNotFound()) {
						try {
							//Kreiranje json fajla sa korisnicima
							dbxClient.files().upload(nazivSkladista  + "/korisnici.json").uploadAndFinish(new ByteArrayInputStream(mainUser.getBytes()));
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							//e1.printStackTrace();
							JOptionPane.showMessageDialog(null, "Niste pravilno uneli putanju!");
							return false;
						}	
					}else {
						JOptionPane.showMessageDialog(null, "Greska!");
						return false;
					}
				}
			}else {
				JOptionPane.showMessageDialog(null, "Greska!");
				return false;
			}
		} catch (Exception err) {
			System.out.print("Greska!");
			System.out.print(err.toString());
		}
		
		

		return true;
	}

	/**
	 * Brise folder na dropbox-u;
	 * 
	 * @param path Putanja do foldera.
	 */
	public void deleteFolder(String path) {
		try {
			Metadata metadata = dbxClient.files().delete(path);
		} catch (DeleteErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DbxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




}
